# IDI Dia a Dia — Blog

Blog de reflexões diárias do movimento messiânico global sobre Israel e a Igreja.

---

## Estrutura

```
idi-dia-a-dia/
├── index.html          ← Página principal do blog
├── netlify.toml        ← Configuração do Netlify
├── admin/
│   ├── index.html      ← Painel de administração (Decap CMS)
│   └── config.yml      ← Configuração dos campos do CMS
└── posts/
    └── artigos.json    ← Base de artigos (atualizar manualmente ou via CMS)
```

---

## Como publicar no Netlify

1. Crie um repositório no GitHub com estes arquivos
2. Acesse netlify.com → "Add new site" → "Import from Git"
3. Conecte ao repositório
4. Em Site settings → Identity → Enable Identity
5. Em Identity → Services → Enable Git Gateway
6. Acesse `/admin` no seu site publicado para entrar no painel

---

## Como adicionar artigos

### Via painel admin (recomendado)
Acesse `seusite.netlify.app/admin` e clique em "New Artigo".

### Via arquivo JSON (manual)
Edite `/posts/artigos.json` seguindo o formato:

```json
{
  "id": "005",
  "slug": "titulo-do-artigo",
  "titulo": "Título do Artigo",
  "autor": "Asher Intrater",
  "data": "2024-06-01",
  "categoria": "Israel e a Igreja",
  "resumo": "Resumo curto para aparecer na listagem.",
  "conteudo": "Texto completo.\n\nSegundo parágrafo.\n\n(Fonte: Tikkun Global Archives)",
  "fonte_original": "https://tikkunglobalarchives.org/link-do-artigo/",
  "destaque": false
}
```

---

## Arquivo de artigos — Tikkun Global Archives

Todos os artigos originais estão disponíveis em:
- **tikkunglobalarchives.org/english-archive-articles** (2000–2020, por ano)
- **tikkunglobalarchives.org/author/asher** (artigos de Asher Intrater especificamente)

Categorias disponíveis no site:
- Israel e a Igreja
- Profecia e Escatologia
- Torah e Vida
- Oração
- Antissemitismo
- Missões Urbanas
- Judaísmo Messiânico
